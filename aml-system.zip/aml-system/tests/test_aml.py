import pytest
from aml_system import check_transaction, sample_transaction

def test_suspicious_transaction():
    result = check_transaction(sample_transaction)
    assert result == True  # Ensure the suspicious transaction is flagged

def test_legitimate_transaction():
    transaction = sample_transaction.copy()
    transaction["amount"] = 500000  # Lower the amount to pass threshold
    result = check_transaction(transaction)
    assert result == False  # Ensure legitimate transaction is not flagged
